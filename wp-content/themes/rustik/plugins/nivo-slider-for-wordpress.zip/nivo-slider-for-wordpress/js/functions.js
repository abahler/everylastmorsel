function Show(section) {
	document.getElementById(section).style.display = 'block';
}

function Hide(section) {
	document.getElementById(section).style.display = 'none';
}