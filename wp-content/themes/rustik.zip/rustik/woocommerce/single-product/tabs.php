<?php
/**
 * Single Product Tabs
 */
 /*
?>
<div class="woocommerce_tabs">
	<ul class="tabs">
		<?php do_action('woocommerce_product_tabs'); ?>
	</ul>
</div>
<?php */ ?> 
<?php do_action('woocommerce_product_tab_panels'); ?>